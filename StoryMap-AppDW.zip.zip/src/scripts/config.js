const CONFIG = {
  BASE_URL: "https://story-api.dicoding.dev/v1",
  VITE_MAPTILER_KEY: "eEKxAVzUA41UwhWFTWVB",
};

export default CONFIG;
